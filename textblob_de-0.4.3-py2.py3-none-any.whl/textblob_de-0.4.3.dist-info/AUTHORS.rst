=======
Credits
=======

`TextBlob`_ Development Lead
----------------------------

* Steven Loria <sloria1@gmail.com>

`textblob-de`_ Author/Maintainer
--------------------------------

* Markus Killer <m.killer@langui.ch>

Contributors
------------

* Hocdoc (Issues #1 - #5)
* ups1974 (Issue #7)
* caspar2d (Issue #8)
* CJAnti (Issue #9)
* retresco (Feature Request: enable tagset conversion in ``PatternTagger``)
* Arttii (Pull Request #11)
* andrewmfiorillo (Pull Request #18, Support for Python 3.7)

.. _TextBlob: https://textblob.readthedocs.org/
.. _textblob-de: https://github.com/markuskiller/textblob-de


